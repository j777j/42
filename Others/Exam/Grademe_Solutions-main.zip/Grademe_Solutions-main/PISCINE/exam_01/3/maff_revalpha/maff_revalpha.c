#include<unistd.h>
int main()
{
	write(1, "zYxWvUtSrQpOnMlKjIhGfEdCbA\n", 27);
}

