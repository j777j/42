#include <unistd.h>

int		main(void)
{
	write(1, "a", 1);
	return (0);
}
